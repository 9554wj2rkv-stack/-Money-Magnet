# Money Magnet ✨

A playful daily money-mindset app: a 3-minute reset, seven mini-games, a real-life Money Evidence Vault and a Money Creature that grows as you practice.

Single-file React app (React 18 + [htm](https://github.com/developit/htm), no build step). Works offline and installs to the iPhone home screen.

## Files

```
index.html             the whole app
manifest.webmanifest   install name, colors, icons
sw.js                  offline support
vendor/                React, ReactDOM and htm (bundled, no CDN needed)
icons/                 app icons
.nojekyll              tells GitHub Pages to serve files as-is
```

## Publish on GitHub Pages

1. Create a new repository on GitHub, e.g. `money-magnet`.
2. Upload every file and folder from this package to the root of the repository (including `.nojekyll`).
3. Go to **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. After a minute the app is live at `https://<your-username>.github.io/money-magnet/`.

All paths are relative, so it also works in any subfolder.

## Install on iPhone

Open the link in Safari → **Share** → **Add to Home Screen**. It opens full screen and works without internet after the first visit.

## Your data

Everything is saved in the browser's `localStorage` on that device only (key `moneyMagnet.v1`). Nothing is sent anywhere.

- Progress does not sync between devices or browsers.
- The home-screen app and Safari may keep separate storage on iPhone.
- Use **Me → Back up my data** now and then, and **Restore from backup** to move to a new phone.
- Other apps on the same `username.github.io` domain share storage space but use different keys, so they won't collide.

## Updating

Edit `index.html` and push. The app checks for the new version whenever it opens online.
If you change files in `vendor/` or `icons/`, also change `VERSION` in `sw.js` (e.g. `mm-v2`) so phones refresh their cached copies.

## Testing locally

Service workers need `https` or `localhost`:

```
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

---

Money Magnet is a mindset practice, not financial advice. Game money is imaginary and never counts as real evidence.
